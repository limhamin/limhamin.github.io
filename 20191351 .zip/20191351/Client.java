package org.javaro.lecture;
public class Client {
	private String name;
	private String clientNumber;
	public Client(String clientNumber) {this.clientNumber=clientNumber;}
	public String getName() {
	return this.name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public String getclientNumber() {
	return this.clientNumber;
	}
	public void setclientNumber(String clientNumber) {
	this.clientNumber = clientNumber;
	}
	public String toString() {
	return "고객전화번호="+this.getclientNumber()+",고객이름="+this.getName();
	}
}

