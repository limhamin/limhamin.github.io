package org.javaro.lecture;

public class Hanbok {
	private String phonenumber;
	private String title;
	private String author;
	private Client client;

	public Hanbok(String phonenumber, String title) {
		this.phonenumber = phonenumber;
		this.title = title;
	}

	public void setphonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getphonenumber() {
		return this.phonenumber;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return this.title;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setclient(Client client) {
		this.client = client;
	}

	public Client getclient() {
		return this.client;
	}

	public String toString() {
		String available;
		if (this.getclient() == null) {
			available = "대여가능";
		} else {
			available = "대여손님=" + this.getclient().getName();
		}
		return "바코드 =" + this.getphonenumber() + ",한복 =" + this.getTitle() + ", 디자이너=" + this.getAuthor() + ","
				+ available; //
	}
}