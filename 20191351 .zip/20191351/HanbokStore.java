package org.javaro.lecture;

import java.util.ArrayList;
import org.javaro.lecture.Hanbok;
import org.javaro.lecture.Client;

public class HanbokStore {
	public String storeName;
	public ArrayList<Hanbok> hanboks;
	public ArrayList<Client> students;

	public HanbokStore(String storeName) {
		this.storeName = storeName;
		hanboks = new ArrayList<Hanbok>();
		students = new ArrayList<Client>();
	}

	public String getStoreName() {
		return this.storeName;
	}

	public ArrayList<Hanbok> gethanboks() {
		return this.hanboks;
	}

	public ArrayList<Client> getclients() {
		return this.students;
	}

	public void addhanbok(Hanbok hanbok) {
		this.hanboks.add(hanbok);
	}

	public void removehanbok(Hanbok hanbok) {
		this.hanboks.remove(hanbok);
	}

	public void addStudent(Client student) {
		this.students.add(student);
	}

	public void removeStudent(Client student) {
		this.students.remove(student);
	}

	public boolean checkOut(Hanbok book, Client student) {
		if (book.getclient() == null) {
			book.setclient(student);
			return true;
		} else {
			return false;
		}
	}

	public boolean checkln(Hanbok book) {
		if (book.getclient() != null) {
			book.setclient(null);
			return true;
		} else {
			return false;
		}
	}

	public ArrayList<Hanbok> getBooksForStudent(Client student) {
		ArrayList<Hanbok> result = new ArrayList<Hanbok>();
		for (Hanbok ahanbok : this.gethanboks()) {
			if ((ahanbok.getclient() != null) && (ahanbok.getclient().getclientNumber().equals(student.getclientNumber()))) {
				result.add(ahanbok);
			}
		}
		return result;
	}

	public ArrayList<Hanbok> getAvailablehanboks() {
		ArrayList<Hanbok> result = new ArrayList<Hanbok>();
		for (Hanbok ahanbok : this.gethanboks()) {
			if (ahanbok.getclient() == null) {
				result.add(ahanbok);
			}
		}
		return result;
	}

	public ArrayList<Hanbok> getUnavailableBoks() {
		ArrayList<Hanbok> result = new ArrayList<Hanbok>();
		for (Hanbok ahanbok : this.gethanboks()) {
			if (ahanbok.getclient() != null) {
				result.add(ahanbok);
			}
		}
		return result;
	}

	public String toString() {
		return this.getStoreName() + "의 보유한복 =" + this.gethanboks().size() + "벌, 고객수=" + this.getclients().size() + "명";
	}

	public void printStatus() {
		System.out.println("한복 현황---\n" + this.toString());
		for (Hanbok ahanbok : this.gethanboks()) {
			System.out.println(ahanbok);
		}
		for (Client student : this.getclients()) {
			int count = this.getBooksForStudent(student).size();
			System.out.println(student + "손님은/는 " + count + "의 한복 대여중");
		}
		System.out.println("현재 대여 가능한 한복:" + this.getAvailablehanboks().size());

	}
}