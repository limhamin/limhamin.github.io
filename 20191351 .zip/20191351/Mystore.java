package org.javaro.lecture;

import org.javaro.lecture.Hanbok;
import org.javaro.lecture.HanbokStore;
import org.javaro.lecture.Client;

public class Mystore {
	public static void main(String[] args) {
		HanbokStore myStore = new HanbokStore("한복대여점");
		Hanbok hanbok1 = new Hanbok("1", "주상전하 한복");
		Hanbok hanbok2 = new Hanbok("2", "남자한복");// 도서등록
		Hanbok hanbok3 = new Hanbok("3", "노비한복");
		Hanbok hanbok4 = new Hanbok("4", "기생한복");
		Hanbok hanbok5 = new Hanbok("5", "선비 한복");
		hanbok1.setAuthor("김홍도");
		hanbok2.setAuthor("신윤복");
		hanbok3.setAuthor("김득신");
		hanbok4.setAuthor("허난설현");
		hanbok5.setAuthor("김세황");
		Client client1 = new Client("01012345678");
		Client client2 = new Client("01043218765");
		Client client3 = new Client("01000000001");
		Client client4 = new Client("01056731245");
		client1.setName("이도형");
		client2.setName("김은수");
		client3.setName("황진영");
		client4.setName("김수겸");
		myStore.addhanbok(hanbok1);
		myStore.addhanbok(hanbok2);
		myStore.addhanbok(hanbok3);
		myStore.addhanbok(hanbok4);
		myStore.addhanbok(hanbok5);
		myStore.addStudent(client1);
		myStore.addStudent(client2);
		myStore.addStudent(client3);
		myStore.addStudent(client4);
		System.out.println("");
		myStore.printStatus();
		System.out.println("노비한복을 황진영에게 대여");
		myStore.checkOut(hanbok3, client3);
		System.out.println("남자한복 황진영에게 대여");
		myStore.checkOut(hanbok2, client3);
		myStore.printStatus();
		System.out.println("노비한복을 반납");
		myStore.checkln(hanbok3);
		System.out.println("노비한복을 김은수에게 대여");
		myStore.checkOut(hanbok3, client2);
		myStore.printStatus();
		System.out.println("왕 한복을을 김은수에게 대여");
		myStore.checkOut(hanbok1, client2);
		System.out.println("기생한복을 김수겸에게 대여");
		myStore.checkOut(hanbok4, client4);
		System.out.println("선비한복 김은수에게 대여");
		myStore.checkOut(hanbok5, client2);
		myStore.printStatus();
		System.out.println("선비한복 반납");
		myStore.checkln(hanbok5);
		myStore.printStatus();
	}
}
