package org.javaro.lecture;

import org.javaro.lecture.Book;
import org.javaro.lecture.BookStore;
import org.javaro.lecture.Student;

public class Mystore {
	public static void main(String[] args) {
		BookStore myStore = new BookStore("도서관");
		Book book1 = new Book("9788901161236", "홍길동전");
		Book book2 = new Book("9788901162135", "심청전");// 도서등록
		Book book3 = new Book("9788901161237", "춘향전");
		Book book4 = new Book("9788901161736", "전재과 평화");
		Book book5 = new Book("9088901161236", "논어 ");
		book1.setAuthor("허균");
		book2.setAuthor("미상");
		book3.setAuthor("미상");
		book4.setAuthor("미국작가");
		book5.setAuthor("공자");
		Student stud1 = new Student("202X1234");
		Student stud2 = new Student("202X5678");
		Student stud3 = new Student("20221234");
		Student stud4 = new Student("20225678");
		stud1.setName("이몽룡");
		stud2.setName("변학도");
		stud3.setName("홍길동");
		stud4.setName("성춘향");
		myStore.addBook(book1);
		myStore.addBook(book2);
		myStore.addBook(book3);
		myStore.addBook(book4);
		myStore.addBook(book5);
		myStore.addStudent(stud1);
		myStore.addStudent(stud2);
		myStore.addStudent(stud3);
		myStore.addStudent(stud4);
		System.out.println("");
		myStore.printStatus();
		System.out.println("book3 춘향전을 stud3 홍길동에게 대출");
		myStore.checkOut(book3, stud3);
		System.out.println("book2 홍길동전을 stud3 홍길동에게 대출");
		myStore.checkOut(book2, stud3);
		myStore.printStatus();
		System.out.println("book2 심청전 반납");
		myStore.checkln(book2);
		System.out.println("book2 심청전은 stud2 변학도에게 대출");
		myStore.checkOut(book2, stud2);
		myStore.printStatus();
		System.out.println("book2 심청전을 stud2 변학도에게 대출");
		myStore.checkOut(book2, stud2);
		System.out.println("book4 전쟁과평화을 stud4 성춘향에게 대출");
		myStore.checkOut(book4, stud4);
		System.out.println("book5논어을 stud2 변학도에게 대출");
		myStore.checkOut(book5, stud2);
		myStore.printStatus();
		System.out.println("book4 전쟁과 평과 반납");
		myStore.printStatus();
	}
}
